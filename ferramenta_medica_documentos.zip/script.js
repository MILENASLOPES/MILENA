const grid = document.getElementById("documentsGrid");
const nav = document.getElementById("categoryNav");
const searchInput = document.getElementById("searchInput");
const resultCount = document.getElementById("resultCount");
const sectionTitle = document.getElementById("sectionTitle");
const sectionKicker = document.getElementById("sectionKicker");
const emptyState = document.getElementById("emptyState");
const sidebar = document.getElementById("sidebar");
const menuToggle = document.getElementById("menuToggle");
const helpModal = document.getElementById("helpModal");

let categoriaAtual = "Todos";
let buscaAtual = "";

const icons = {
  PDF: "PDF",
  DOCX: "W",
  DOC: "W",
  XLSX: "X",
  XLS: "X",
  TXT: "≡",
  HTML: "</>",
  LINK: "↗"
};

function normalizar(texto = "") {
  return texto
    .toLocaleLowerCase("pt-BR")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

function documentosFiltrados() {
  const termo = normalizar(buscaAtual);
  return DOCUMENTOS.filter(doc => {
    const correspondeCategoria = categoriaAtual === "Todos" || doc.categoria === categoriaAtual;
    const campoBusca = normalizar([
      doc.titulo,
      doc.categoria,
      doc.descricao,
      ...(doc.tags || [])
    ].join(" "));
    return correspondeCategoria && campoBusca.includes(termo);
  });
}

function criarNavegacao() {
  nav.innerHTML = '<span class="nav-caption">NAVEGAÇÃO</span>';

  CATEGORIAS.forEach(cat => {
    const quantidade = cat.nome === "Todos"
      ? DOCUMENTOS.length
      : DOCUMENTOS.filter(doc => doc.categoria === cat.nome).length;

    const button = document.createElement("button");
    button.className = `category-button ${cat.nome === categoriaAtual ? "active" : ""}`;
    button.innerHTML = `
      <span class="category-icon">${cat.icone}</span>
      <span>${cat.nome}</span>
      <span class="category-count">${quantidade}</span>
    `;
    button.addEventListener("click", () => {
      categoriaAtual = cat.nome;
      criarNavegacao();
      renderizar();
      sidebar.classList.remove("open");
    });
    nav.appendChild(button);
  });
}

function renderizar() {
  const docs = documentosFiltrados();
  grid.innerHTML = "";

  sectionKicker.textContent = buscaAtual ? "RESULTADOS DA BUSCA" : "BIBLIOTECA";
  sectionTitle.textContent = categoriaAtual === "Todos" ? "Todos os documentos" : categoriaAtual;
  resultCount.textContent = `${docs.length} ${docs.length === 1 ? "item" : "itens"}`;

  docs.forEach(doc => {
    const card = document.createElement("article");
    card.className = "document-card";

    const linkTarget = doc.tipo === "LINK" ? "_blank" : "_blank";
    const rel = 'rel="noopener noreferrer"';

    card.innerHTML = `
      <div class="card-top">
        <span class="file-icon">${icons[doc.tipo] || "•"}</span>
        <span class="file-type">${doc.tipo}</span>
      </div>
      <h3>${doc.titulo}</h3>
      <p>${doc.descricao || "Documento de apoio à prática clínica."}</p>
      <div class="card-footer">
        <span class="category-label">${doc.categoria}</span>
        <a class="open-link" href="${doc.arquivo}" target="${linkTarget}" ${rel}>Abrir arquivo →</a>
      </div>
    `;
    grid.appendChild(card);
  });

  const semResultados = docs.length === 0;
  emptyState.hidden = !semResultados;
  grid.hidden = semResultados;
}

searchInput.addEventListener("input", event => {
  buscaAtual = event.target.value.trim();
  renderizar();
});

document.addEventListener("keydown", event => {
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
    event.preventDefault();
    searchInput.focus();
  }
  if (event.key === "Escape") sidebar.classList.remove("open");
});

menuToggle.addEventListener("click", () => sidebar.classList.toggle("open"));

document.getElementById("helpButton").addEventListener("click", () => helpModal.showModal());
document.querySelector("[data-close-modal]").addEventListener("click", () => helpModal.close());

helpModal.addEventListener("click", event => {
  const area = helpModal.getBoundingClientRect();
  const fora = event.clientX < area.left || event.clientX > area.right ||
               event.clientY < area.top || event.clientY > area.bottom;
  if (fora) helpModal.close();
});

criarNavegacao();
renderizar();
