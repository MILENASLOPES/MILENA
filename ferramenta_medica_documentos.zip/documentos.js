// CADASTRE SEUS DOCUMENTOS NESTE ARQUIVO.
// O caminho precisa corresponder ao local exato do arquivo dentro da pasta do site.

const DOCUMENTOS = [
  {
    titulo: "Receituário simples",
    categoria: "Receituários",
    descricao: "Modelo editável para prescrição ambulatorial.",
    tipo: "DOCX",
    arquivo: "documentos/receituarios/COLOQUE-SEU-ARQUIVO-AQUI.docx",
    tags: ["receita", "prescrição", "ambulatório"]
  },
  {
    titulo: "Anamnese clínica adulta",
    categoria: "Anamneses",
    descricao: "Estrutura de consulta clínica para pacientes adultos.",
    tipo: "DOCX",
    arquivo: "documentos/anamneses/COLOQUE-SEU-ARQUIVO-AQUI.docx",
    tags: ["adulto", "consulta", "história clínica"]
  },
  {
    titulo: "Anamnese pediátrica",
    categoria: "Anamneses",
    descricao: "Modelo de consulta e acompanhamento pediátrico.",
    tipo: "DOCX",
    arquivo: "documentos/anamneses/COLOQUE-SEU-ARQUIVO-AQUI.docx",
    tags: ["pediatria", "criança", "consulta"]
  },
  {
    titulo: "Orientações de sinais de alarme",
    categoria: "Orientações",
    descricao: "Modelo geral para entrega ao paciente ou responsável.",
    tipo: "PDF",
    arquivo: "documentos/orientacoes/COLOQUE-SEU-ARQUIVO-AQUI.pdf",
    tags: ["alta", "retorno", "orientação"]
  },
  {
    titulo: "Declaração de comparecimento",
    categoria: "Formulários",
    descricao: "Modelo de declaração para atendimento médico.",
    tipo: "DOCX",
    arquivo: "documentos/formularios/COLOQUE-SEU-ARQUIVO-AQUI.docx",
    tags: ["declaração", "comparecimento"]
  },
  {
    titulo: "Atestado médico",
    categoria: "Formulários",
    descricao: "Modelo editável de atestado médico.",
    tipo: "DOCX",
    arquivo: "documentos/formularios/COLOQUE-SEU-ARQUIVO-AQUI.docx",
    tags: ["atestado", "afastamento"]
  }
];

const CATEGORIAS = [
  { nome: "Todos", icone: "⌂" },
  { nome: "Receituários", icone: "Rx" },
  { nome: "Anamneses", icone: "▤" },
  { nome: "Orientações", icone: "ⓘ" },
  { nome: "Formulários", icone: "□" }
];
