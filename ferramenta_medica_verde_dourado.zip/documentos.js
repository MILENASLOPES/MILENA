const DOCUMENTOS = [
  {
    titulo: "Receituário simples",
    categoria: "Receituários",
    descricao: "Modelo editável para prescrição ambulatorial.",
    tipo: "DOCX",
    arquivo: "documentos/receituarios/receituario-simples.docx",
    tags: ["receita", "prescrição", "ambulatório"]
  },
  {
    titulo: "Anamnese clínica adulta",
    categoria: "Anamneses",
    descricao: "Modelo estruturado para consulta clínica de adultos.",
    tipo: "DOCX",
    arquivo: "documentos/anamneses/anamnese-adulta.docx",
    tags: ["adulto", "consulta", "história clínica"]
  },
  {
    titulo: "Anamnese pediátrica",
    categoria: "Anamneses",
    descricao: "Modelo de consulta e acompanhamento pediátrico.",
    tipo: "DOCX",
    arquivo: "documentos/anamneses/anamnese-pediatrica.docx",
    tags: ["pediatria", "criança", "consulta"]
  },
  {
    titulo: "Orientações de sinais de alarme",
    categoria: "Orientações",
    descricao: "Modelo de orientações para alta e retorno médico.",
    tipo: "PDF",
    arquivo: "documentos/orientacoes/sinais-de-alarme.pdf",
    tags: ["alta", "retorno", "orientações"]
  },
  {
    titulo: "Declaração de comparecimento",
    categoria: "Formulários",
    descricao: "Modelo de declaração de comparecimento.",
    tipo: "DOCX",
    arquivo: "documentos/formularios/declaracao-comparecimento.docx",
    tags: ["declaração", "comparecimento"]
  },
  {
    titulo: "Atestado médico",
    categoria: "Formulários",
    descricao: "Modelo editável de atestado médico.",
    tipo: "DOCX",
    arquivo: "documentos/formularios/atestado-medico.docx",
    tags: ["atestado", "afastamento"]
  }
];

const CATEGORIAS = [
  { nome: "Todos", icone: "⌂" },
  { nome: "Receituários", icone: "Rx" },
  { nome: "Anamneses", icone: "▤" },
  { nome: "Orientações", icone: "ⓘ" },
  { nome: "Formulários", icone: "□" }
];
