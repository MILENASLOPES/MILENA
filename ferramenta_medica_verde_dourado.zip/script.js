const grid = document.getElementById("documentsGrid");
const nav = document.getElementById("categoryNav");
const searchInput = document.getElementById("searchInput");
const resultCount = document.getElementById("resultCount");
const sectionTitle = document.getElementById("sectionTitle");
const sectionKicker = document.getElementById("sectionKicker");
const emptyState = document.getElementById("emptyState");
const sidebar = document.getElementById("sidebar");
const menuToggle = document.getElementById("menuToggle");
const helpButton = document.getElementById("helpButton");
const helpModal = document.getElementById("helpModal");
const closeModal = document.getElementById("closeModal");

let categoriaAtual = "Todos";
let buscaAtual = "";

const iconesArquivos = {
  PDF: "PDF",
  DOCX: "W",
  DOC: "W",
  XLSX: "X",
  XLS: "X",
  TXT: "TXT",
  HTML: "</>",
  LINK: "↗"
};

function normalizarTexto(texto = "") {
  return texto
    .toLocaleLowerCase("pt-BR")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

function obterDocumentosFiltrados() {
  const termo = normalizarTexto(buscaAtual);

  return DOCUMENTOS.filter((documento) => {
    const correspondeCategoria =
      categoriaAtual === "Todos" ||
      documento.categoria === categoriaAtual;

    const conteudoPesquisavel = normalizarTexto(
      [
        documento.titulo,
        documento.categoria,
        documento.descricao,
        ...(documento.tags || [])
      ].join(" ")
    );

    return correspondeCategoria && conteudoPesquisavel.includes(termo);
  });
}

function criarMenuCategorias() {
  nav.innerHTML = '<span class="nav-caption">NAVEGAÇÃO</span>';

  CATEGORIAS.forEach((categoria) => {
    const quantidade =
      categoria.nome === "Todos"
        ? DOCUMENTOS.length
        : DOCUMENTOS.filter(
            (documento) => documento.categoria === categoria.nome
          ).length;

    const botao = document.createElement("button");

    botao.className =
      categoria.nome === categoriaAtual
        ? "category-button active"
        : "category-button";

    botao.innerHTML = `
      <span class="category-icon">${categoria.icone}</span>
      <span>${categoria.nome}</span>
      <span class="category-count">${quantidade}</span>
    `;

    botao.addEventListener("click", () => {
      categoriaAtual = categoria.nome;
      criarMenuCategorias();
      renderizarDocumentos();
      sidebar.classList.remove("open");
    });

    nav.appendChild(botao);
  });
}

function criarCardDocumento(documento) {
  const card = document.createElement("article");
  card.className = "document-card";

  const icone = iconesArquivos[documento.tipo] || "•";

  card.innerHTML = `
    <div class="card-top">
      <span class="file-icon">${icone}</span>
      <span class="file-type">${documento.tipo}</span>
    </div>

    <h3>${documento.titulo}</h3>

    <p>
      ${documento.descricao || "Documento de apoio à prática clínica."}
    </p>

    <div class="card-footer">
      <span class="category-label">${documento.categoria}</span>

      <a
        class="open-link"
        href="${documento.arquivo}"
        target="_blank"
        rel="noopener noreferrer"
      >
        Abrir arquivo →
      </a>
    </div>
  `;

  return card;
}

function renderizarDocumentos() {
  const documentos = obterDocumentosFiltrados();

  grid.innerHTML = "";

  sectionKicker.textContent =
    buscaAtual ? "RESULTADOS DA BUSCA" : "BIBLIOTECA";

  sectionTitle.textContent =
    categoriaAtual === "Todos"
      ? "Todos os documentos"
      : categoriaAtual;

  resultCount.textContent =
    documentos.length === 1
      ? "1 item"
      : `${documentos.length} itens`;

  documentos.forEach((documento) => {
    grid.appendChild(criarCardDocumento(documento));
  });

  const semResultados = documentos.length === 0;

  emptyState.hidden = !semResultados;
  grid.hidden = semResultados;
}

searchInput.addEventListener("input", (evento) => {
  buscaAtual = evento.target.value.trim();
  renderizarDocumentos();
});

document.addEventListener("keydown", (evento) => {
  const pressionouAtalho =
    (evento.ctrlKey || evento.metaKey) &&
    evento.key.toLowerCase() === "k";

  if (pressionouAtalho) {
    evento.preventDefault();
    searchInput.focus();
  }

  if (evento.key === "Escape") {
    sidebar.classList.remove("open");

    if (helpModal.open) {
      helpModal.close();
    }
  }
});

menuToggle.addEventListener("click", () => {
  sidebar.classList.toggle("open");
});

helpButton.addEventListener("click", () => {
  helpModal.showModal();
});

closeModal.addEventListener("click", () => {
  helpModal.close();
});

helpModal.addEventListener("click", (evento) => {
  const dimensoes = helpModal.getBoundingClientRect();

  const clicouFora =
    evento.clientX < dimensoes.left ||
    evento.clientX > dimensoes.right ||
    evento.clientY < dimensoes.top ||
    evento.clientY > dimensoes.bottom;

  if (clicouFora) {
    helpModal.close();
  }
});

criarMenuCategorias();
renderizarDocumentos();
